const chatBox = document.getElementById("chat-box");

const chatFlow = [
    {
        question: "What do you need help with?",
        options: [
            { text: "Insurance Coverage", answer: "Your policy covers doctor visits, prescriptions, and more." },
            { text: "Filing a Claim", answer: "You can file a claim through our online portal." },
            { text: "Adding a Dependent", answer: "You can add a dependent by submitting the required documents." }
        ]
    },
    {
        question: "How do I check my claim status?",
        options: [
            { text: "Online", answer: "You can check your claim status through our website under 'My Claims'." },
            { text: "Call Support", answer: "You can call our support team at 1800-XXX-XXXX for claim status." }
        ]
    },
    {
        question: "Can I upgrade my policy?",
        options: [
            { text: "Yes", answer: "You can upgrade your policy by contacting our sales team." },
            { text: "No", answer: "Your current plan provides extensive coverage." }
        ]
    },
    {
        question: "What is the claim processing time?",
        options: [
            { text: "Standard", answer: "Claims are processed within 5-7 business days." },
            { text: "Urgent", answer: "For urgent claims, processing takes 1-2 business days." }
        ]
    },
    {
        question: "How do I reset my password?",
        options: [
            { text: "Via Email", answer: "Click 'Forgot Password' on the login page and follow the steps sent to your email." },
            { text: "Via OTP", answer: "Use the OTP sent to your registered mobile number to reset your password." }
        ]
    },
    {
        question: "What documents are required for a claim?",
        options: [
            { text: "Medical Reports", answer: "You need to submit medical reports, bills, and doctor's prescriptions." },
            { text: "Identity Proof", answer: "You need to provide a government-approved identity proof." }
        ]
    }
];

let questionIndex = 0; // Track the current question

function startChat() {
    chatBox.innerHTML = ""; // Clear previous chat
    askQuestion();
}

function askQuestion() {
    if (questionIndex < chatFlow.length) {
        let item = chatFlow[questionIndex];
        addMessage(item.question, "question"); // Show question in light blue box
        displayOptions(item.options); // Show options in light gray boxes
    }
}

function addMessage(text, className) {
    const messageDiv = document.createElement("div");
    messageDiv.classList.add(className);
    messageDiv.textContent = text;
    chatBox.appendChild(messageDiv);
    chatBox.scrollTop = chatBox.scrollHeight; // Auto-scroll
}

function displayOptions(options) {
    const optionsContainer = document.createElement("div");
    optionsContainer.classList.add("options-container");

    options.forEach(option => {
        const button = document.createElement("button");
        button.textContent = option.text;
        button.classList.add("option-button");
        button.onclick = () => handleOptionSelect(option.answer, optionsContainer);
        optionsContainer.appendChild(button);
    });

    chatBox.appendChild(optionsContainer);
}

function handleOptionSelect(answer, optionsContainer) {
    optionsContainer.remove(); // Remove options after selection
    addMessage(answer, "answer"); // Show answer in dark blue box

    setTimeout(() => {
        questionIndex++; // Move to the next question
        askQuestion();
    }, 1000); // Wait before displaying the next question
}

function showExitPopup() {
    // Create modal overlay
    let overlay = document.createElement("div");
    overlay.classList.add("modal-overlay");
    overlay.id = "exit-modal";

    // Create modal box
    let modal = document.createElement("div");
    modal.classList.add("modal-box");

    // Modal content
    modal.innerHTML = `
        <h2>Are you sure you want to exit?</h2>
        <div class="modal-buttons">
            <button class="modal-button yes" onclick="exitChat()">Yes</button>
            <button class="modal-button no" onclick="closePopup()">No</button>
        </div>
    `;

    overlay.appendChild(modal);
    document.body.appendChild(overlay);
}

function closePopup() {
    let modal = document.getElementById("exit-modal");
    if (modal) modal.remove();
}

function exitChat() {
    window.location.href = "index.html"; // Redirect to home
}

// Start the chatbot
startChat();
